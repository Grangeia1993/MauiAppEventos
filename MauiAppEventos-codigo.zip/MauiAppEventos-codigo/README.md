# Cadastro de Eventos - .NET MAUI

## Como montar o projeto

1. No Visual Studio 2022: **Criar novo projeto → .NET MAUI App**. Nome do projeto: `MauiAppEventos`
   (se usar outro nome, troque `MauiAppEventos` nos namespaces dos arquivos).
2. Crie a pasta **Models** e adicione o arquivo `Evento.cs`.
3. Substitua o conteúdo de `MainPage.xaml` e `MainPage.xaml.cs` pelos arquivos desta pasta.
4. Adicione uma página nova: **Adicionar → Novo Item → .NET MAUI ContentPage (XAML)**, com o nome `ResumoPage`.
   Substitua o conteúdo de `ResumoPage.xaml` e `ResumoPage.xaml.cs`.
5. Selecione **Windows Machine** e pressione **F5**.

## Onde cada requisito está

- **BindingContext + model Evento**: `MainPage.xaml.cs` (`BindingContext = _evento`) e `Models/Evento.cs`.
- **DateTime e TimeSpan**: `Evento.Duracao` (`DataTermino.Date - DataInicio.Date`) e `Evento.DuracaoEmDias`.
- **Custo total**: `Evento.CustoTotal` (participantes x custo por participante).
- **Página de resumo**: `ResumoPage`, aberta com `Navigation.PushAsync`.

## Entrega

- **GitHub**: rode `dotnet new gitignore` na pasta da solução, depois `git init`, `git add .`, `git commit`, e faça o push.
- **PDF**: prints da tela de cadastro preenchida e da tela de resumo (Win + Shift + S), colados em um documento e exportados como PDF.
- **Vídeo (alternativa)**: grave a tela explicando o `Evento.cs`, o BindingContext e a navegação, e mostrando o app funcionando.
