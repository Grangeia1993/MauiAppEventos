using MauiAppEventos.Models;

namespace MauiAppEventos;

public partial class MainPage : ContentPage
{
    private Evento _evento = new();

    public MainPage()
    {
        InitializeComponent();
        BindingContext = _evento;
    }

    private async void OnCadastrarClicked(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(_evento.Nome))
        {
            await DisplayAlert("Atenção", "Informe o nome do evento.", "OK");
            return;
        }

        if (_evento.DataTermino.Date < _evento.DataInicio.Date)
        {
            await DisplayAlert("Atenção", "A data de término não pode ser anterior à data de início.", "OK");
            return;
        }

        if (_evento.NumeroParticipantes <= 0)
        {
            await DisplayAlert("Atenção", "Informe um número de participantes maior que zero.", "OK");
            return;
        }

        if (string.IsNullOrWhiteSpace(_evento.Local))
        {
            await DisplayAlert("Atenção", "Informe o local do evento.", "OK");
            return;
        }

        if (_evento.CustoPorParticipante < 0)
        {
            await DisplayAlert("Atenção", "O custo por participante não pode ser negativo.", "OK");
            return;
        }

        await Navigation.PushAsync(new ResumoPage(_evento));
    }

    private void OnLimparClicked(object? sender, EventArgs e)
    {
        _evento = new Evento();
        BindingContext = _evento;
    }
}
