using System.ComponentModel;
using System.Globalization;
using System.Runtime.CompilerServices;

namespace MauiAppEventos.Models;

public class Evento : INotifyPropertyChanged
{
    private static readonly CultureInfo PtBr = new("pt-BR");

    private string _nome = string.Empty;
    private DateTime _dataInicio = DateTime.Today;
    private DateTime _dataTermino = DateTime.Today;
    private int _numeroParticipantes;
    private string _local = string.Empty;
    private decimal _custoPorParticipante;

    public event PropertyChangedEventHandler? PropertyChanged;

    // ----- Propriedades preenchidas na tela de cadastro -----

    public string Nome
    {
        get => _nome;
        set { _nome = value; OnPropertyChanged(); }
    }

    public DateTime DataInicio
    {
        get => _dataInicio;
        set { _dataInicio = value; OnPropertyChanged(); AtualizarCalculos(); }
    }

    public DateTime DataTermino
    {
        get => _dataTermino;
        set { _dataTermino = value; OnPropertyChanged(); AtualizarCalculos(); }
    }

    public int NumeroParticipantes
    {
        get => _numeroParticipantes;
        set { _numeroParticipantes = value; OnPropertyChanged(); AtualizarCalculos(); }
    }

    public string Local
    {
        get => _local;
        set { _local = value; OnPropertyChanged(); }
    }

    public decimal CustoPorParticipante
    {
        get => _custoPorParticipante;
        set { _custoPorParticipante = value; OnPropertyChanged(); AtualizarCalculos(); }
    }

    // ----- Lógica calculada -----

    /// <summary>Diferença entre as datas, calculada com DateTime e representada por um TimeSpan.</summary>
    public TimeSpan Duracao => DataTermino.Date - DataInicio.Date;

    /// <summary>
    /// Duração em dias, contando o dia de início e o de término
    /// (um evento que começa e termina no mesmo dia dura 1 dia).
    /// Para contar só a diferença, troque por: Duracao.Days
    /// </summary>
    public int DuracaoEmDias => Duracao < TimeSpan.Zero ? 0 : Duracao.Days + 1;

    public decimal CustoTotal => NumeroParticipantes * CustoPorParticipante;

    // ----- Textos formatados para exibição -----

    public string DuracaoFormatada => $"{DuracaoEmDias} dia(s)";

    public string DiferencaTimeSpan => Duracao.ToString();

    public string DataInicioFormatada => DataInicio.ToString("dd/MM/yyyy", PtBr);

    public string DataTerminoFormatada => DataTermino.ToString("dd/MM/yyyy", PtBr);

    public string CustoPorParticipanteFormatado => CustoPorParticipante.ToString("C", PtBr);

    public string CustoTotalFormatado => CustoTotal.ToString("C", PtBr);

    // ----- Notificação de mudanças (necessária para o Binding atualizar a tela) -----

    private void AtualizarCalculos()
    {
        OnPropertyChanged(nameof(Duracao));
        OnPropertyChanged(nameof(DuracaoEmDias));
        OnPropertyChanged(nameof(DuracaoFormatada));
        OnPropertyChanged(nameof(DiferencaTimeSpan));
        OnPropertyChanged(nameof(CustoTotal));
        OnPropertyChanged(nameof(CustoTotalFormatado));
        OnPropertyChanged(nameof(CustoPorParticipanteFormatado));
        OnPropertyChanged(nameof(DataInicioFormatada));
        OnPropertyChanged(nameof(DataTerminoFormatada));
    }

    protected void OnPropertyChanged([CallerMemberName] string? nome = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nome));
}
